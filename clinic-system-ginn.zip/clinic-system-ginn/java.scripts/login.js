import { initializeApp } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-app.js";
import {
  getAuth,
  signInWithEmailAndPassword,
} from "https://www.gstatic.com/firebasejs/9.0.0/firebase-auth.js";
const firebaseConfig = {
  apiKey: "AIzaSyA6ruE8_Je180qm8QvhqXpXDV3jZ0uYi_w",
  authDomain: "cfsi-clinic.firebaseapp.com",
  projectId: "cfsi-clinic",
  storageBucket: "cfsi-clinic.firebasestorage.app",
  messagingSenderId: "1033385834319",
  appId: "1:1033385834319:web:4157095c0bed489770773a",
  measurementId: "G-2WZT5LYKGP",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

document.getElementById("login").addEventListener("click", async (event) => {
  event.preventDefault();
  const email = document.querySelector("#email").value;
  const password = document.querySelector("#password").value;

  if (email === "" || password === "") {
    alert("No inputs available");
    return;
  } else {
    try {
      console.log(email);
      const userCredential = await signInWithEmailAndPassword(
        auth,
        email,
        password
      );
      const user = userCredential.user;
      console.log("User is logged in");

      window.location.assign(`adminportal.html`);
    } catch (error) {
      console.error(`Error signing in user:`, error);
    }
  }
});
