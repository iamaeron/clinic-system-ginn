import { initializeApp } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-app.js";
import {
  getAuth,
  signOut,
} from "https://www.gstatic.com/firebasejs/9.0.0/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyA6ruE8_Je180qm8QvhqXpXDV3jZ0uYi_w",
  authDomain: "cfsi-clinic.firebaseapp.com",
  projectId: "cfsi-clinic",
  storageBucket: "cfsi-clinic.firebasestorage.app",
  messagingSenderId: "1033385834319",
  appId: "1:1033385834319:web:4157095c0bed489770773a",
  measurementId: "G-2WZT5LYKGP",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

const auth = getAuth(app);

if (!localStorage.getItem("schoolBranch")) {
  signOut(auth)
    .then(() => {
      window.location.assign("index.html");
      localStorage.removeItem("schoolBranch");
    })
    .catch((error) => {
      console.error("eRROR signingout user:", error);
    });
}

document.getElementById("logout").addEventListener("click", () => {
  console.log("logout");
  signOut(auth)
    .then(() => {
      window.location.assign("index.html");
      localStorage.removeItem("schoolBranch");
    })
    .catch((error) => {
      console.error("eRROR signingout user:", error);
    });
});
