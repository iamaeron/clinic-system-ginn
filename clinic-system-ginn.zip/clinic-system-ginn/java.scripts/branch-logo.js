const schoolLogo = document.querySelector("[data-school-logo]");
const schoolBg = document.querySelector("[data-school-bg]");
const schoolBranchTitle = document.querySelector("[data-school-branch]");

const branch = localStorage.getItem("schoolBranch");
if (!branch) {
  window.location.assign("/index.html");
} else {
  switch (branch) {
    case "mabiga":
      schoolLogo.src = "/IMAGES_MABIGA/MFatima Logo.png";
      if (schoolBranchTitle) schoolBranchTitle.textContent = "SHS MABIGA";
      break;

    case "dau":
      schoolLogo.src = "/IMAGES_DAU_M2/JHS & ELEM DAU.png";
      if (schoolBranchTitle) schoolBranchTitle.textContent = "JHS & ELEM DAU";
      break;

    case "mabalacat-shs":
      schoolLogo.src = "/IMAGES_MABALACAT_M1/SHS MABALACAT.png";
      if (schoolBranchTitle) schoolBranchTitle.textContent = "SHS MABALACAT";
      break;

    case "mabalacat-jhs":
      schoolLogo.src = "/IMAGES_MABACALAT_M2/JHS & ELEM  MABALACAT.png";
      if (schoolBranchTitle)
        schoolBranchTitle.textContent = "JHS & ELEM MABALACAT";
      break;

    default:
      schoolLogo.src = "/IMAGES_MABIGA/MFatima Logo.png";
  }
}
