import { initializeApp } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-analytics.js";
import {
  getAuth,
  createUserWithEmailAndPassword,
  sendEmailVerification,
  updateProfile,
  onAuthStateChanged,
} from "https://www.gstatic.com/firebasejs/9.0.0/firebase-auth.js";
import {
  getFirestore,
  collection,
  addDoc,
  setDoc,
  doc,
  query,
  getDocs,
  getDoc,
  where,
  deleteDoc,
} from "https://www.gstatic.com/firebasejs/9.0.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyA6ruE8_Je180qm8QvhqXpXDV3jZ0uYi_w",
  authDomain: "cfsi-clinic.firebaseapp.com",
  projectId: "cfsi-clinic",
  storageBucket: "cfsi-clinic.firebasestorage.app",
  messagingSenderId: "1033385834319",
  appId: "1:1033385834319:web:4157095c0bed489770773a",
  measurementId: "G-2WZT5LYKGP",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const db = getFirestore(app);

const auth = getAuth(app);

const urlParams = new URLSearchParams(window.location.search);
const email = urlParams.get("email");
console.log("Extracted Email:", email);

document.getElementById("continue").addEventListener("click", async () => {
  console.log("continue");
  const ecode = document.getElementById("code").value.trim();

  if (email === "") {
    alert("No user.");
    return;
  }

  if (ecode === "") {
    console.log("empty code");
    alert("Invalid code!");
    return;
  }

  console.log(email, ecode);

  try {
    const q = query(collection(db, "verification-codes"));
    const snap = await getDocs(q);

    if (snap.empty) {
      alert("Invalid verification code.");
      return;
    }

    snap.docs.map(async (verification) => {
      const verif = verification.data();

      if (!snap.empty) {
        if (verif.verificationCode === ecode || verif.userEmail === email) {
          await deleteDoc(doc(db, "verification-codes", verification.id));
          console.log("Verification successful");
          alert("Email verified successfully!");
          window.location.assign("loginpage.html");
        } else {
          console.log("Incorrect code");
          alert("Incorrect verification code!");
        }
      } else {
        console.log("Incorrect code");
        alert("Incorrect verification code!");
      }
    });
  } catch (error) {
    console.error("Error verifying code:", error);
  }
});
